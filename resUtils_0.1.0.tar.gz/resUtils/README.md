# resUtils
Utility functions for creating resumes and CVs using R and markdown
